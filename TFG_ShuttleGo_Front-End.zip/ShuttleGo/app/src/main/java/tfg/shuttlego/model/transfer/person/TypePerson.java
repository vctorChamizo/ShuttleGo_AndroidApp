package tfg.shuttlego.model.transfer.person;

public enum TypePerson {

    ADMIN,
    DRIVER,
    USER
}
